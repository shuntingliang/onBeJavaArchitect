// 主应用入口 - 布局与菜单切换
const { createApp, computed, ref } = Vue;

const app = createApp({
  setup() {
    const collapsed = ref(false);
    const activeMenu = ref('project');
    const menuTitleMap = {
      project: '项目信息',
      history: '历史运行',
      algorithm: '算法参数配置',
      strategy: '策略库',
      optimal: '最优策略'
    };
    const menuTitle = computed(() => menuTitleMap[activeMenu.value] || '');
    const handleMenuSelect = (key) => { activeMenu.value = key; };
    const currentPage = computed(() => {
      const map = {
        project: 'project-info-page',
        history: 'history-run-page',
        algorithm: 'algorithm-config-page',
        strategy: 'strategy-library-page',
        optimal: 'optimal-strategy-page'
      };
      return map[activeMenu.value];
    });
    return { collapsed, activeMenu, menuTitle, handleMenuSelect, currentPage };
  }
});

// 注册 Element Plus
app.use(ElementPlus);

// 注册图标
for (const [key, comp] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, comp);
}

// 注册页面组件（来自 window.PageComponents 注册表）
const PageComponents = window.PageComponents || {};
for (const [name, comp] of Object.entries(PageComponents)) {
  app.component(name, comp);
}

// 挂载，并捕获任何运行期错误，直接显示在页面上
try {
  app.mount('#app');
  if (window.__bootSetStatus) window.__bootSetStatus('已挂载 ✓');
} catch (e) {
  if (window.__bootShowErr) window.__bootShowErr('app.mount 失败: ' + (e && e.stack ? e.stack : e));
}

// Vue 运行期错误捕获
app.config.errorHandler = (err, instance, info) => {
  if (window.__bootShowErr) window.__bootShowErr('Vue 运行错误: ' + (err && err.stack ? err.stack : err) + '\n信息: ' + info);
};
